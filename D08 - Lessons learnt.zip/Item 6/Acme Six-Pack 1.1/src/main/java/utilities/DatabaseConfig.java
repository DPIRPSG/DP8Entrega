package utilities;

public interface DatabaseConfig {

	public final String PersistenceUnit = "Acme-Six-Pack-1.1";
	
}
